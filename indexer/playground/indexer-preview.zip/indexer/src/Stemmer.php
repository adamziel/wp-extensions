<?php
declare(strict_types=1);

/**
 * Contract for optional language-aware term stemming.
 *
 * Stemmers receive normalized terms from the language pipeline and must return
 * a normalized term string. They should be conservative: returning the original
 * term is preferred when a language is unsupported or an implementation is not
 * available.
 */
interface WP_FTS_Stemmer
{
    /**
     * Stem one normalized term for a language partition.
     *
     * @param string $term Normalized term text, not namespaced.
     * @param string $language Canonical language tag such as `en` or `pl`.
     * @return string Stemmed term, or the original term when no safe stemming is
     *         available.
     */
    public function stem(string $term, string $language): string;
}

/**
 * Stemmer implementation that deliberately leaves all terms unchanged.
 */
final class WP_FTS_NoopStemmer implements WP_FTS_Stemmer
{
    /**
     * Return the input term exactly as supplied.
     *
     * @param string $term Normalized term text.
     * @param string $language Canonical language tag; accepted for interface
     *        compatibility.
     * @return string The unchanged term.
     */
    public function stem(string $term, string $language): string
    {
        return $term;
    }
}

/**
 * Deterministic baseline stemmer for top spoken languages without full packs.
 *
 * This is intentionally smaller than a Snowball or dictionary lemmatizer. It
 * applies conservative suffix/affix rules that improve first-pass recall for
 * common forms while avoiding word-family dictionaries or query expansion.
 */
final class WP_FTS_BaselineLanguageStemmer implements WP_FTS_Stemmer
{
    /**
     * Stem one normalized term for supported baseline languages.
     *
     * @param string $term Normalized term text.
     * @param string $language Canonical or locale-style language tag.
     * @return string Baseline stem, or original term for unsupported languages.
     */
    public function stem(string $term, string $language): string
    {
        return match ($this->base_language($language)) {
            'bn' => $this->stem_bengali($term),
            'ur' => $this->stem_urdu($term),
            default => $term,
        };
    }

    /**
     * Stable descriptor for stale-index detection.
     */
    public function index_signature(): string
    {
        return 'wp-fts-baseline-language-stemmer:v10:' . sha1(implode('|', [
            'bn=suffix:classifier-plural-case:v2',
            'ur=suffix:plural-oblique:v2',
        ]));
    }

    /**
     * Urdu: keep letters intact and only strip common plural/oblique suffixes.
     */
    private function stem_urdu(string $term): string
    {
        return $this->strip_suffix_rules($term, [
            ['یاں', 'ی', 3],
            ['وں', '', 3],
            ['یں', '', 3],
            ['ات', '', 3],
            ['ے', '', 3],
        ]);
    }

    /**
     * Bengali: strip common classifier, plural, and case suffixes only.
     */
    private function stem_bengali(string $term): string
    {
        return $this->strip_suffix_rules($term, [
            ['গুলোকে', '', 2],
            ['গুলোতে', '', 2],
            ['গুলিকে', '', 2],
            ['গুলিতে', '', 2],
            ['গুলোর', '', 2],
            ['গুলির', '', 2],
            ['গুলো', '', 2],
            ['গুলি', '', 2],
            ['দেরকে', '', 3],
            ['দের', '', 3],
            ['টিকে', '', 2],
            ['টিতে', '', 2],
            ['টির', '', 2],
            ['টাকে', '', 2],
            ['টাতে', '', 2],
            ['টার', '', 2],
            ['টি', '', 2],
            ['টা', '', 2],
            ['ের', '', 3],
            ['কে', '', 3],
            ['রা', '', 3],
            ['তে', '', 3],
        ]);
    }

    /**
     * @param array<int,array{0:string,1:string,2:int}> $rules
     */
    private function strip_prefix_rules(string $term, array $rules): string
    {
        foreach ($rules as [$prefix, $replacement, $minStemLength]) {
            if (!str_starts_with($term, $prefix)) {
                continue;
            }

            $candidate = $replacement . substr($term, strlen($prefix));
            if ($this->char_length($candidate) >= $minStemLength) {
                return $candidate;
            }
        }

        return $term;
    }

    /**
     * @param array<int,array{0:string,1:string,2:int,3?:string[]}> $rules
     */
    private function strip_suffix_rules(string $term, array $rules): string
    {
        foreach ($rules as $rule) {
            [$suffix, $replacement, $minStemLength] = $rule;
            $protectedEndings = $rule[3] ?? [];
            if (!str_ends_with($term, $suffix)) {
                continue;
            }
            if ($this->has_any_suffix($term, $protectedEndings)) {
                continue;
            }

            $candidate = substr($term, 0, -strlen($suffix)) . $replacement;
            if ($this->char_length($candidate) >= $minStemLength) {
                return $candidate;
            }
        }

        return $term;
    }

    /**
     * @param string[] $suffixes
     */
    private function has_any_suffix(string $term, array $suffixes): bool
    {
        foreach ($suffixes as $suffix) {
            if ($suffix !== '' && str_ends_with($term, $suffix)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Count UTF-8 characters with mbstring or PCRE before falling back to bytes.
     */
    private function char_length(string $term): int
    {
        if (function_exists('mb_strlen')) {
            return mb_strlen($term, 'UTF-8');
        }

        $chars = [];
        if (preg_match_all('/./us', $term, $chars) !== false) {
            return count($chars[0]);
        }

        return strlen($term);
    }

    /**
     * Reduce a language tag to the lower-case primary language subtag.
     */
    private function base_language(string $language): string
    {
        $language = strtolower(str_replace('_', '-', trim($language)));
        $separator = strpos($language, '-');

        return $separator === false ? $language : substr($language, 0, $separator);
    }
}

/**
 * Adapts a user callable to the stemmer interface.
 *
 * Legacy callers often supplied one-argument callbacks such as `metaphone`.
 * This adapter preserves that form and only passes `$language` when the
 * callable requires at least two parameters or is variadic.
 */
final class WP_FTS_CallbackStemmer implements WP_FTS_Stemmer
{
    /** @var callable */
    private $callback;
    private bool $passesLanguage;

    /**
     * @param callable $callback Function accepting either `($term)` or
     *        `($term, $language)` and returning a replacement term.
     */
    public function __construct(callable $callback)
    {
        $this->callback = $callback;
        $this->passesLanguage = $this->accepts_language($callback);
    }

    /**
     * Run the configured callback with the arity it expects.
     *
     * @param string $term Normalized term text.
     * @param string $language Canonical language tag.
     * @return string Callback result cast to string.
     */
    public function stem(string $term, string $language): string
    {
        return (string) (
            $this->passesLanguage
                ? ($this->callback)($term, $language)
                : ($this->callback)($term)
        );
    }

    /**
     * Decide whether the callback should receive the language argument.
     *
     * Optional second parameters are not enough: many PHP callbacks use that
     * slot for unrelated options. Required two-argument and variadic callbacks
     * are treated as language-aware.
     *
     * @param callable $callback User callback being adapted.
     * @return bool True when `stem()` should call it with two arguments.
     */
    private function accepts_language(callable $callback): bool
    {
        $reflection = new ReflectionFunction(Closure::fromCallable($callback));

        // Preserve the legacy one-argument stemmer contract for callables such
        // as metaphone(), whose optional second parameter is not a language.
        return $reflection->isVariadic() || $reflection->getNumberOfRequiredParameters() >= 2;
    }
}

/**
 * Uses the optional Wamania Snowball package for languages verified by tests.
 *
 * Unsupported languages and missing packages are no-ops. The allowlist is
 * intentionally narrow so enabling stemming does not silently switch to
 * algorithms that diverge from the bundled Snowball compliance data.
 */
final class WP_FTS_SnowballStemmer implements WP_FTS_Stemmer
{
    /** @var array<string,bool> */
    private array $supportedLanguages;
    private WP_FTS_EnglishSnowballStemmer $englishStemmer;
    private WP_FTS_ArabicSnowballStemmer $arabicStemmer;
    private WP_FTS_SpanishSnowballStemmer $spanishStemmer;
    private WP_FTS_FrenchSnowballStemmer $frenchStemmer;
    private WP_FTS_PortugueseSnowballStemmer $portugueseStemmer;
    private WP_FTS_IndonesianSnowballStemmer $indonesianStemmer;
    private WP_FTS_HindiSnowballStemmer $hindiStemmer;

    /**
     * Initialize the set of Snowball languages accepted by this adapter.
     */
    public function __construct(
        ?WP_FTS_EnglishSnowballStemmer $englishStemmer = null,
        ?WP_FTS_SpanishSnowballStemmer $spanishStemmer = null,
        ?WP_FTS_FrenchSnowballStemmer $frenchStemmer = null,
        ?WP_FTS_PortugueseSnowballStemmer $portugueseStemmer = null,
        ?WP_FTS_IndonesianSnowballStemmer $indonesianStemmer = null,
        ?WP_FTS_HindiSnowballStemmer $hindiStemmer = null,
        ?WP_FTS_ArabicSnowballStemmer $arabicStemmer = null
    )
    {
        // Expose only implementations that match the official Snowball
        // fixtures exactly. Arabic, English, Spanish, French, Hindi,
        // Portuguese, and Indonesian are local generated Snowball ports;
        // Catalan and Dutch Porter remain Wamania-backed optional paths. Other
        // Wamania classes currently diverge from the current snowball-data
        // outputs and are treated as no-ops until their algorithms are
        // replaced or patched.
        $this->supportedLanguages = array_fill_keys([
            'ar',
            'ca',
            'en',
            'es',
            'fr',
            'hi',
            'id',
            'nl',
            'pt',
        ], true);
        $this->englishStemmer = $englishStemmer ?? new WP_FTS_EnglishSnowballStemmer();
        $this->arabicStemmer = $arabicStemmer ?? new WP_FTS_ArabicSnowballStemmer();
        $this->spanishStemmer = $spanishStemmer ?? new WP_FTS_SpanishSnowballStemmer();
        $this->frenchStemmer = $frenchStemmer ?? new WP_FTS_FrenchSnowballStemmer();
        $this->portugueseStemmer = $portugueseStemmer ?? new WP_FTS_PortugueseSnowballStemmer();
        $this->indonesianStemmer = $indonesianStemmer ?? new WP_FTS_IndonesianSnowballStemmer();
        $this->hindiStemmer = $hindiStemmer ?? new WP_FTS_HindiSnowballStemmer();
    }

    /**
     * Report whether the optional Snowball dependency is installed.
     *
     * @return bool True when `Wamania\Snowball\StemmerFactory` can be used.
     */
    public function is_available(): bool
    {
        return class_exists('\\Wamania\\Snowball\\StemmerFactory');
    }

    /**
     * Check whether this adapter is allowed to stem the given language.
     *
     * @param string $language Canonical or locale-style language tag.
     * @return bool True for supported base languages only.
     */
    public function supports_language(string $language): bool
    {
        return isset($this->supportedLanguages[$this->base_language($language)]);
    }

    /**
     * Report whether a supported language has an available runtime path.
     *
     * Arabic, English, Spanish, French, Hindi, Portuguese, and Indonesian are
     * bundled as generated PHP; Wamania-backed languages remain optional and
     * no-op safely when Composer packages are absent.
     *
     * @param string $language Canonical or locale-style language tag.
     * @return bool True when `stem()` can apply a verified implementation.
     */
    public function is_language_available(string $language): bool
    {
        $language = $this->base_language($language);
        if (in_array($language, ['ar', 'en', 'es', 'fr', 'hi', 'id', 'pt'], true)) {
            return true;
        }

        return isset($this->supportedLanguages[$language]) && $this->is_available();
    }

    /**
     * Return the implementation identity used for review and index signatures.
     */
    public function source_identity(string $language = ''): string
    {
        $language = $this->base_language($language);
        if ($language === 'en') {
            return $this->englishStemmer->source_identity();
        }

        if ($language === 'ar') {
            return $this->arabicStemmer->source_identity();
        }

        if ($language === 'es') {
            return $this->spanishStemmer->source_identity();
        }

        if ($language === 'fr') {
            return $this->frenchStemmer->source_identity();
        }

        if ($language === 'hi') {
            return $this->hindiStemmer->source_identity();
        }

        if ($language === 'pt') {
            return $this->portugueseStemmer->source_identity();
        }

        if ($language === 'id') {
            return $this->indonesianStemmer->source_identity();
        }

        if ($language === 'nl') {
            return 'wamania/php-stemmer Dutch Porter mapped to nl; verified against snowball-data dutch_porter fixtures when Wamania is installed';
        }

        if ($language === 'ca') {
            return 'wamania/php-stemmer Catalan; verified against snowball-data catalan fixtures when Wamania is installed';
        }

        return 'unsupported Snowball language; no-op';
    }

    /**
     * Stable descriptor for stale-index detection.
     */
    public function index_signature(): string
    {
        return 'wp-fts-snowball-stemmer:v8:' . sha1(implode('|', [
            'ar=' . WP_FTS_ArabicSnowballStemmer::VARIANT . '@snowball-data-arabic-9196214-gzip',
            'ca=wamania-catalan',
            'en=' . WP_FTS_EnglishSnowballStemmer::VARIANT . '@snowball-data-13803281',
            'es=' . WP_FTS_SpanishSnowballStemmer::VARIANT . '@snowball-data-spanish-28378',
            'fr=' . WP_FTS_FrenchSnowballStemmer::VARIANT . '@snowball-data-french-21653',
            'hi=' . WP_FTS_HindiSnowballStemmer::VARIANT . '@snowball-data-hindi-65118',
            'id=' . WP_FTS_IndonesianSnowballStemmer::VARIANT . '@snowball-data-indonesian-64586',
            'nl=wamania-dutch-porter',
            'pt=' . WP_FTS_PortugueseSnowballStemmer::VARIANT . '@snowball-data-portuguese-32016',
        ]));
    }

    /**
     * Stem with Snowball when the package and language support are present.
     *
     * Failures are swallowed and return the original term so indexing/searching
     * does not become dependent on an optional package at runtime.
     *
     * @param string $term Normalized term text.
     * @param string $language Canonical or locale-style language tag.
     * @return string Stemmed term or original term.
     */
    public function stem(string $term, string $language): string
    {
        $language = $this->base_language($language);
        if (!isset($this->supportedLanguages[$language])) {
            return $term;
        }

        if ($language === 'en') {
            return $this->englishStemmer->stem_word($term);
        }

        if ($language === 'ar') {
            return $this->arabicStemmer->stem_word($term);
        }

        if ($language === 'es') {
            return $this->spanishStemmer->stem_word($term);
        }

        if ($language === 'fr') {
            return $this->frenchStemmer->stem_word($term);
        }

        if ($language === 'hi') {
            return $this->hindiStemmer->stem_word($term);
        }

        if ($language === 'pt') {
            return $this->portugueseStemmer->stem_word($term);
        }

        if ($language === 'id') {
            return $this->indonesianStemmer->stem_word($term);
        }

        if (!$this->is_available()) {
            return $term;
        }

        try {
            $stemmer = \Wamania\Snowball\StemmerFactory::create($language);
            return (string) $stemmer->stem($term);
        } catch (Throwable) {
            return $term;
        }
    }

    /**
     * Reduce a language tag to the lower-case primary language subtag.
     */
    private function base_language(string $language): string
    {
        $language = strtolower(str_replace('_', '-', trim($language)));
        $separator = strpos($language, '-');

        return $separator === false ? $language : substr($language, 0, $separator);
    }
}

/**
 * Polish stemmer with stable conservative and opt-in verified modes.
 *
 * The default conservative mode preserves the historical suffix-only behavior.
 * The `verified` mode first consults a compact fixture slice and then falls
 * back to the same conservative suffix path for unknown, unprotected terms.
 */
final class WP_FTS_PolishStemmer implements WP_FTS_Stemmer
{
    private string $mode;

    /**
     * @param string $mode `conservative` enables the suffix list, `verified`
     *        enables the fixture-backed slice plus conservative fallback, and
     *        `none` disables Polish stemming while preserving the adapter.
     */
    public function __construct(string $mode = 'conservative')
    {
        $this->mode = $this->normalize_mode($mode);
    }

    /**
     * Stem Polish terms when enabled and leave every other language unchanged.
     *
     * @param string $term Normalized term text.
     * @param string $language Canonical or locale-style language tag.
     * @return string Stemmed term or original term.
     */
    public function stem(string $term, string $language): string
    {
        if ($this->base_language($language) !== 'pl' || $this->mode === 'none') {
            return $term;
        }

        if ($this->mode === 'verified') {
            return $this->verified_stem($term);
        }

        return $this->conservative_suffix_stem($term);
    }

    /**
     * Return a stable descriptor for analyzer/index stale-document checks.
     */
    public function index_signature(): string
    {
        $version = $this->mode === 'verified'
            ? ':' . WP_FTS_PolishVerifiedStemmerData::VERSION
            : '';

        return 'wp-fts-polish-stemmer:' . $this->mode . $version;
    }

    /**
     * Normalize unknown mode strings to the historical conservative behavior.
     */
    private function normalize_mode(string $mode): string
    {
        $mode = strtolower(trim($mode));

        return in_array($mode, ['conservative', 'verified', 'none'], true)
            ? $mode
            : 'conservative';
    }

    /**
     * Use the verified fixture slice, then fall back conservatively.
     *
     * Protected rows are checked before the stem map so ambiguous forms remain
     * no-ops if future fixture slices add nearby paradigms.
     */
    private function verified_stem(string $term): string
    {
        if (isset(WP_FTS_PolishVerifiedStemmerData::protected_term_map()[$term])) {
            return $term;
        }

        return WP_FTS_PolishVerifiedStemmerData::stem_map()[$term]
            ?? $this->conservative_suffix_stem($term);
    }

    /**
     * Remove one known suffix only when the remaining stem stays meaningful.
     *
     * Stopgap only. The verified mode above is still a fixture-backed stemmer
     * slice, not a replacement for a full Stempel or Morfologik lemmatizer.
     *
     * @param string $term Normalized Polish term.
     * @return string Term with one conservative suffix removed, or original.
     */
    private function conservative_suffix_stem(string $term): string
    {
        $suffixes = [
            'owego',
            'owemu',
            'ami',
            'ach',
            'ego',
            'emu',
            'ych',
            'ymi',
            'owa',
            'owe',
            'owi',
            'cie',
            'nia',
            'om',
            'em',
            'ie',
            'iu',
        ];

        foreach ($suffixes as $suffix) {
            if (!str_ends_with($term, $suffix)) {
                continue;
            }

            $candidate = substr($term, 0, -strlen($suffix));
            if ($this->char_length($candidate) >= 3) {
                return $candidate;
            }
        }

        return $term;
    }

    /**
     * Count characters with mbstring when present and bytes otherwise.
     */
    private function char_length(string $term): int
    {
        return function_exists('mb_strlen') ? mb_strlen($term, 'UTF-8') : strlen($term);
    }

    /**
     * Reduce a language tag to the lower-case primary language subtag.
     */
    private function base_language(string $language): string
    {
        $language = strtolower(str_replace('_', '-', trim($language)));
        $separator = strpos($language, '-');

        return $separator === false ? $language : substr($language, 0, $separator);
    }
}
