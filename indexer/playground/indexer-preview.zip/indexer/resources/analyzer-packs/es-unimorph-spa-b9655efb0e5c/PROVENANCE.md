# UniMorph Analyzer Pack Provenance

This pack is generated from source-approved UniMorph data through the repository importer. It contains normalized surface-to-lemma runtime rows and no runtime network access.

- Pack ID: `es-unimorph-spa-b9655efb0e5c`
- Language: `es`
- Source repository: https://github.com/unimorph/spa
- Source commit: `b9655efb0e5ce0f99809badaa7f4e93017ab8430`
- Source file: `spa`
- Source SHA-256: `7a165d4b44eb078d23964f3eee3813f5140c5df0ffab0143c806c562e67f8771`
- License: `CC-BY-SA-3.0` https://creativecommons.org/licenses/by-sa/3.0/
- Importer command: `php indexer/tools/import-unimorph-lemma-pack.php --source=<unimorph-source> --out=<pack-dir> --language=es --pack-id=es-unimorph-spa-b9655efb0e5c --version=b9655efb0e5c-unimorph-v1 --source-name=<approved-unimorph-source-name> --source-url=https://github.com/unimorph/spa/blob/b9655efb0e5ce0f99809badaa7f4e93017ab8430/spa --license=CC-BY-SA-3.0 --attribution=<required-attribution> --runtime-compression=gzip`
- Runtime rows: `794521`
- Runtime files: `8`
- Runtime digest SHA-256: `c68efa7dfa78f0b1442473c2770ee486965b0a308a63446d653f7929f2dcd54f`

The generated pack is default-disabled. Callers must opt in through `lemma_packs_by_lang` or `lemmatizer_packs_by_lang`.
