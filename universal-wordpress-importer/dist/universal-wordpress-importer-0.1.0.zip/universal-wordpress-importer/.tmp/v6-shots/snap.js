// Quick screenshot helper: open an HTML file in headless Chromium, write PNG.
// Usage: node snap.js <chromium> <input.html> <output.png> [width]
const fs = require('fs');
const os = require('os');
const path = require('path');
const childProcess = require('child_process');

const chromium = process.argv[2];
const inputPath = path.resolve(process.argv[3]);
const outputPath = path.resolve(process.argv[4]);
const width = parseInt(process.argv[5] || '1280', 10);

if (!chromium || !inputPath || !outputPath) {
	process.stderr.write('Usage: node snap.js <chromium> <input.html> <output.png> [width]\n');
	process.exit(2);
}

const args = [
	'--headless=new',
	'--no-sandbox',
	'--disable-gpu',
	'--hide-scrollbars',
	'--window-size=' + width + ',1700',
	'--virtual-time-budget=2000',
	'--screenshot=' + outputPath,
	'file://' + inputPath,
];
const result = childProcess.spawnSync(chromium, args, { stdio: 'inherit' });
process.exit(result.status || 0);
