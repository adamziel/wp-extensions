Read shared brief: .tmp/importer-setup-wizard-v4-prompts/shared-brief.md

You are Worker A. You own exactly these files:
- docs/importer-progress-flow-explorations/setup-wizard-v4/options/option-01.html
- docs/importer-progress-flow-explorations/setup-wizard-v4/options/option-02.html
- docs/importer-progress-flow-explorations/setup-wizard-v4/options/option-03.html
- docs/importer-progress-flow-explorations/setup-wizard-v4/options/option-04.html

Create four high-fidelity interactive setup-wizard variations:
1. Guided cards wizard: source type cards, right-hand import preview, compact stepper.
2. WP admin native wizard: feels like a polished WordPress admin screen with metabox-like panels.
3. Split-pane setup: left source browser/tree, right configuration and run summary.
4. Checklist wizard: progressive checklist with expandable steps and inline validation.

Make them visually distinct from each other while following the real importer capabilities in the shared brief. Edit files directly. Final response should list files created and any caveats.
