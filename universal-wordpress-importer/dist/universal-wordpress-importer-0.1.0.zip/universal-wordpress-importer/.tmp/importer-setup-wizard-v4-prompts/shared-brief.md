Build high-fidelity, interactive HTML/CSS/JS prototypes for the Universal Importer setup wizard.

Destination:
- Repo: /home/claude/wp-extensions-pages-main
- Directory: docs/importer-progress-flow-explorations/setup-wizard-v4/options/
- Each option must be a standalone HTML file with inline CSS and inline JS. No external runtime.

The design direction:
- User explicitly likes "Universal Importer · setup wizard". Create variations of that direction, not broad unrelated dashboards.
- These are high-fidelity proposals, not wireframes.
- They must be meaningfully different from each other while staying in the setup-wizard family.
- Make the first viewport useful: source selection and the primary action should be visible without hunting.
- Make the pages clickable enough to understand the flow. Tabs, cards, toggles, source chips, URL mode choices, GitHub directory selection, import simulation, decisions, and progress should visibly respond.

Stay true to what the importer supports:
- Source inputs: GitHub repo / branch / subdirectory URL; WordPress site or REST root; RSS, Atom, RDF, OPML/feed list; URL or reachable page; server path; uploaded files; uploaded folder.
- File/upload formats: PDF, EPUB, HTML/HTM, Markdown, text, WXR/XML, ZIP, folder.
- Options: URL treatment with ask / preserve / rewrite listed domains; old-site domains; import as drafts; dry run.
- GitHub directory picker exists as a modal/tree/filter path selection.
- Progress stages: Read source, Prepare content, URL treatment, Import media, Write pages, Finish.
- Running import can show pending/running/done, source item counts, prepared documents, media counts, comments, drafts/published pages, recent events.
- Decisions can interrupt the flow, especially "Rewrite old-site URLs to this site?" with selectable domains and actions: Rewrite selected, rewrite all, keep all.
- Completion can offer "View imported content".
- Abort is available during active runs.

Avoid unsupported claims:
- Do not invent Shopify, Notion, Drive, Slack, CMS connectors, AI mapping, ecommerce import, design-system import, or account auth flows.
- Do not imply it imports arbitrary database tables or custom post types unless framed as WXR/WordPress content.
- Do not hide the real URL treatment and dry-run/draft choices.

Quality gates:
- Include a visible source value or selected source.
- Include the six import stages by name somewhere in the option.
- Include a primary import action.
- Include at least one interactive source choice.
- Include at least one interactive option choice for URL treatment/dry run/drafts.
- Include a run simulation that changes visible state through multiple stages.
- Include at least one realistic attention/decision state or progress detail.
- Use stable responsive layout, no overlapping text, no decorative-only generic gradients.
