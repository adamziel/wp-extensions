Read shared brief: .tmp/importer-setup-wizard-v4-prompts/shared-brief.md

You are Worker D. You own exactly these files:
- docs/importer-progress-flow-explorations/setup-wizard-v4/options/option-13.html
- docs/importer-progress-flow-explorations/setup-wizard-v4/options/option-14.html
- docs/importer-progress-flow-explorations/setup-wizard-v4/options/option-15.html
- docs/importer-progress-flow-explorations/setup-wizard-v4/options/option-16.html

Create four high-fidelity interactive setup-wizard variations:
13. Source catalog wizard: supported source families as a catalog, selected source expands into setup.
14. Timeline setup wizard: setup and import progress represented as a clear sequence with decisions in context.
15. Comparison wizard: draft vs publish and dry run vs write are compared before import.
16. URL-treatment-first wizard: old domains, rewrite modes, and decision handling are the primary design feature.

Make them visually distinct from each other while following the real importer capabilities in the shared brief. Edit files directly. Final response should list files created and any caveats.
