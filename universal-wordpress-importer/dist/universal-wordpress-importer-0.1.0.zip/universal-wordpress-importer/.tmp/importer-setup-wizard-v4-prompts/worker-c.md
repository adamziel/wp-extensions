Read shared brief: .tmp/importer-setup-wizard-v4-prompts/shared-brief.md

You are Worker C. You own exactly these files:
- docs/importer-progress-flow-explorations/setup-wizard-v4/options/option-09.html
- docs/importer-progress-flow-explorations/setup-wizard-v4/options/option-10.html
- docs/importer-progress-flow-explorations/setup-wizard-v4/options/option-11.html
- docs/importer-progress-flow-explorations/setup-wizard-v4/options/option-12.html

Create four high-fidelity interactive setup-wizard variations:
9. Review-before-import wizard: source summary, detected items, decisions preview before starting.
10. Minimal single-column wizard: calm focused setup with progressive disclosure.
11. Dense operator wizard: power-user controls visible, technical details collapsible but present.
12. Recovery-aware wizard: pending/running/blocked/done states and abort/retry affordances.

Make them visually distinct from each other while following the real importer capabilities in the shared brief. Edit files directly. Final response should list files created and any caveats.
